# Chalkboard for Android, what it cannot do

Beta 0.5.

Written down properly because a browser that overstates its privacy is
worse than one that admits the gaps. If you are relying on something in
here, check this list first.

Three kinds of limit below. Things that are switched off because the API
does not exist, things that are structural and cannot be fixed by code,
and things that are simply not built yet.

---

## 1. Privacy settings that are manual, not automatic

GeckoView gives no public way to set arbitrary Gecko preferences from
code. There is no `setPreference` in the public API. Everything in this
group is real and works, but you have to switch it on by hand.

**How.** Open a tab, go to `about:config`, search the name, set the
value. It sticks.

| What | Preference | Set it to |
| --- | --- | --- |
| Encrypted DNS, always | `network.trr.mode` | `3` |
| Which DNS server | `network.trr.uri` | `https://dns.quad9.net/dns-query` |
| Hide where you came from | `network.http.referer.XOriginPolicy` | `2` |
| Trim the referrer as well | `network.http.referer.XOriginTrimmingPolicy` | `2` |
| Resist fingerprinting | `privacy.resistFingerprinting` | `true` |
| Strip ?fbclid= from links | `privacy.query_stripping.enabled` | `true` |
| No guessing where you go next | `network.prefetch-next` | `false` |
| No DNS prefetch | `network.dns.disablePrefetch` | `true` |
| No predictor | `network.predictor.enabled` | `false` |

I removed the tray switches for these rather than leave controls that
quietly do nothing.

**Could this be fixed?** Probably, using the `configFilePath` runtime
setting to ship a preferences file with the app. Not attempted yet.

## 2. Global Privacy Control is gone

The setting that tells websites not to sell your data. The GeckoView
method for it does not exist, so it was removed rather than faked. Not
currently available in Chalkboard on Android by any route.

## 3. Structural, cannot be fixed here

**Search sees your IP address.** Whoever returns your results knows
where the request came from. Chalkboard does not own a search index, and
nothing on the phone can hide this. Choosing an engine that promises not
to log is the real answer, not a technical one.

**No DRM video.** Netflix, Disney and Spotify will not play. They need a
licensed decryption component that is not in this build.

**Extensions are Firefox add-ons, not Chrome ones.** That is the trade
that made Android possible at all, since Chrome on Android has never
supported extensions. uBlock Origin, Dark Reader and ClearURLs work.
Anything Chrome only does not.

**The APK is large.** GeckoView bundles an entire browser engine, which
adds roughly 30 to 40 MB before any of Chalkboard's own code. The build
splits by processor type so a phone downloads only its own slice, but
there is no way to make it small.

## 4. Not built yet

- **No auto update.** You update by installing a newer APK by hand.
- **No sync, no password manager.** Nothing leaves your phone, which
  also means nothing follows you to another device.
- **No downloads manager.** Files download, but there is no list of
  them inside the browser.
- **No reader mode**, no print, no find on page.
- **Tabs do not survive being force quit.** Normal closing is fine.
- **Per site permissions are not remembered.** You are asked every time
  rather than once per site. Safer, more annoying.

## 5. The honest one about newness

This code compiled for the first time on the day it was written, and it
has never been through a real security review or been used by anyone but
its author. Firefox patches serious holes within days and has thousands
of people looking for them. This has one person and a build server.

The engine underneath is Mozilla's and is properly maintained, so the
risky part is not the web rendering. The risky part is everything
Chalkboard wraps around it.

Treat it as a beta, because that is what the version number says.

---

## What does work

Worth listing, so this is not only bad news.

- **Ad and tracker blocking**, Gecko's own, running inside the engine
  where a page cannot switch it off. Ads, analytics, social trackers,
  cryptominers and fingerprinters.
- **Total Cookie Protection.** Every site gets its own cookie jar, so a
  tracker on one site cannot read what it stored on another.
- **Popup blocking**, refused at the moment the page asks, with a bar
  offering to open it anyway for the one time you wanted it.
- **Camera, microphone and location** refused unless you say yes.
- **Private tabs** that leave nothing on disk.
- **Forget everything**, which clears cookies, cache, history,
  bookmarks and settings.
- **A plain Firefox user agent**, so you do not stand out as one of the
  handful of people running this browser. That one survived because
  GeckoView has a real public setter for it.
- **Add-ons install in one tap** from addons.mozilla.org.
- **No telemetry of any kind**, because none was ever written. There is
  no server to send anything to.
