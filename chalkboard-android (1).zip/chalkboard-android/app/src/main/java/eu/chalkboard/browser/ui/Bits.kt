package eu.chalkboard.browser.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import eu.chalkboard.browser.Board
import kotlin.math.abs
import kotlin.math.roundToInt

/* ================================================================== *
 * capsule, the shape everything in Chalkboard is made of
 * ================================================================== */

@Composable
fun Capsule(
    board: Board,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    outlined: Boolean = true,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(board.dCapsule),
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier
            .clip(shape)
            .then(if (filled) Modifier.background(board.cFill) else Modifier)
            .then(if (outlined) Modifier.border(board.dStroke, board.cStroke, shape) else Modifier),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
fun RoundBtn(
    board: Board,
    enabled: Boolean = true,
    active: Boolean = false,
    size: androidx.compose.ui.unit.Dp = 38.dp,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (active) board.cStroke.copy(alpha = .26f) else board.cFill)
            .border(board.dStroke, board.cStroke.copy(alpha = if (enabled) 1f else .3f), CircleShape)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun Label(text: String, board: Board, dim: Boolean = false, size: Int = 0) {
    Text(
        text,
        color = if (dim) board.cInkDim else board.cInk,
        fontSize = if (size > 0) size.sp else board.tFont,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun SectionTitle(text: String, board: Board) {
    Text(
        text.uppercase(),
        color = board.cStroke,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.6.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 10.dp),
    )
}

/* ================================================================== *
 * controls
 * ================================================================== */

@Composable
fun TokenSlider(
    name: String,
    board: Board,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    suffix: String = "",
    onChange: (Float) -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Text(name, color = board.cInkDim, fontSize = 12.sp, modifier = Modifier.width(74.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = board.cStroke,
                activeTrackColor = board.cStroke,
                inactiveTrackColor = board.faint(.35f),
            ),
            modifier = Modifier.weight(1f),
        )
        Text(
            value.roundToInt().toString() + suffix,
            color = board.cInkDim, fontSize = 11.sp,
            modifier = Modifier.width(42.dp),
        )
    }
}

@Composable
fun Toggle(name: String, board: Board, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(vertical = 9.dp),
    ) {
        Text(name, color = board.cInkDim, fontSize = 12.5.sp, modifier = Modifier.weight(1f))
        Box(
            Modifier
                .size(38.dp, 22.dp)
                .clip(CircleShape)
                .background(if (checked) board.cStroke.copy(alpha = .24f) else Color.Transparent)
                .border(board.dStroke, board.cStroke, CircleShape),
            contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart,
        ) {
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(board.cStroke)
            )
        }
    }
}

@Composable
fun PillButton(text: String, board: Board, strong: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(36.dp)
            .clip(RoundedCornerShape(board.dCapsule))
            .border(
                board.dStroke,
                if (strong) board.cStroke else board.faint(.4f),
                RoundedCornerShape(board.dCapsule)
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (strong) board.cStroke else board.cInkDim, fontSize = 12.5.sp)
    }
}

/* ================================================================== *
 * exact colour picker
 * ================================================================== */

private val PURES = listOf(
    "#FF0000", "#FF7F00", "#FFFF00", "#00FF00", "#00FFFF", "#0000FF",
    "#7F00FF", "#FF00FF", "#FFFFFF", "#C0C0C0", "#808080", "#000000",
    "#FF7F5C", "#63D7E8", "#7FE3A0", "#F0C85E",
)

/**
 * Type a hex code for the exact colour, drag hue, saturation and lightness
 * to hunt for one, or tap a pure colour. All three write the same value.
 */
@Composable
fun ColourRow(name: String, board: Board, hex: String, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    var text by remember(hex) { mutableStateOf(hex) }

    val hsl = remember(hex) { toHsl(Board.hex(hex)) }

    Column(Modifier.padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(name, color = board.cInkDim, fontSize = 12.sp, modifier = Modifier.width(74.dp))

            Box(
                Modifier
                    .size(34.dp, 28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Board.hex(hex))
                    .border(1.dp, board.faint(.45f), RoundedCornerShape(8.dp))
                    .clickable { open = !open }
            )
            Spacer(Modifier.width(8.dp))

            Capsule(board, Modifier.weight(1f).height(28.dp), shape = RoundedCornerShape(8.dp)) {
                BasicTextField(
                    value = text,
                    onValueChange = { v ->
                        text = v
                        clean(v)?.let(onChange)
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = board.cInk, fontSize = 12.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(board.cStroke),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                )
            }
        }

        AnimatedVisibility(open) {
            Column(Modifier.padding(top = 10.dp, start = 74.dp)) {
                TokenSlider("Hue", board, hsl[0], 0f..360f) {
                    onChange(fromHsl(it, hsl[1], hsl[2]))
                }
                TokenSlider("Sat", board, hsl[1], 0f..100f) {
                    onChange(fromHsl(hsl[0], it, hsl[2]))
                }
                TokenSlider("Light", board, hsl[2], 0f..100f) {
                    onChange(fromHsl(hsl[0], hsl[1], it))
                }
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(top = 8.dp),
                ) {
                    items(PURES.size) { i ->
                        Box(
                            Modifier
                                .size(26.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Board.hex(PURES[i]))
                                .border(1.dp, Color.White.copy(alpha = .16f), RoundedCornerShape(6.dp))
                                .clickable { text = PURES[i]; onChange(PURES[i]) }
                        )
                    }
                }
            }
        }
    }
}

private fun clean(s: String): String? {
    var h = s.trim().removePrefix("#")
    if (h.length == 3) h = "${h[0]}${h[0]}${h[1]}${h[1]}${h[2]}${h[2]}"
    return if (Regex("^[0-9a-fA-F]{6}$").matches(h)) "#${h.uppercase()}" else null
}

private fun toHsl(c: Color): FloatArray {
    val r = c.red; val g = c.green; val b = c.blue
    val max = maxOf(r, g, b); val min = minOf(r, g, b); val d = max - min
    var h = 0f
    val l = (max + min) / 2f
    val s = if (d == 0f) 0f else d / (1 - abs(2 * l - 1))
    if (d != 0f) {
        h = when (max) {
            r -> 60f * (((g - b) / d) % 6f)
            g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }
    }
    if (h < 0) h += 360f
    return floatArrayOf(h, s * 100f, l * 100f)
}

private fun fromHsl(hDeg: Float, sPct: Float, lPct: Float): String {
    val s = sPct / 100f
    val l = lPct / 100f
    val c = (1 - abs(2 * l - 1)) * s
    val x = c * (1 - abs((hDeg / 60f) % 2f - 1))
    val m = l - c / 2
    val (r, g, b) = when {
        hDeg < 60 -> Triple(c, x, 0f)
        hDeg < 120 -> Triple(x, c, 0f)
        hDeg < 180 -> Triple(0f, c, x)
        hDeg < 240 -> Triple(0f, x, c)
        hDeg < 300 -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    fun p(v: Float) = (((v + m) * 255).roundToInt().coerceIn(0, 255)).toString(16).padStart(2, '0')
    return "#${p(r)}${p(g)}${p(b)}".uppercase()
}
