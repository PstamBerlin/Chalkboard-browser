package eu.chalkboard.browser

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Every setting Chalkboard has. It is a plain JSON file in the app's own
 * private folder. No account, no server, nothing to sync and nothing to
 * leak. Uninstall the app and it is gone.
 */
@Serializable
data class Prefs(
    // privacy
    val blockPopups: Boolean = true,
    val blockAds: Boolean = true,
    val trimReferrer: Boolean = true,
    val encryptedDns: Boolean = true,
    val dnsServer: String = "https://dns.quad9.net/dns-query",
    val resistFingerprinting: Boolean = false,
    val keepHistory: Boolean = true,
    val clearOnExit: Boolean = false,
    val askPermissions: Boolean = true,

    // browsing
    val search: String = "https://duckduckgo.com/?q=%s",
    val textScale: Float = 1.0f,
    val homeUrl: String = "chalk:new",

    // feel
    val haptics: Boolean = true,
    val pullToRefresh: Boolean = true,
    val hideBarsOnScroll: Boolean = true,
    val toolbarAtBottom: Boolean = true,
    val showTabStrip: Boolean = true,
    val showFavicons: Boolean = true,
) {
    companion object {
        private const val FILE = "prefs.json"
        private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

        fun load(context: Context): Prefs = runCatching {
            val f = java.io.File(context.filesDir, FILE)
            if (!f.exists()) Prefs() else json.decodeFromString<Prefs>(f.readText())
        }.getOrElse { Prefs() }

        fun save(context: Context, prefs: Prefs) = runCatching {
            java.io.File(context.filesDir, FILE).writeText(json.encodeToString(prefs))
        }

        fun forget(context: Context) {
            listOf(FILE, Board.FILE, GestureMap.FILE, "history.json", "bookmarks.json")
                .forEach { java.io.File(context.filesDir, it).delete() }
        }
    }
}

/** One visited page. Stored locally, and only if you asked for history. */
@Serializable
data class Visit(val url: String, val title: String, val at: Long)

object History {
    private const val FILE = "history.json"
    private const val CAP = 3000
    private val json = Json { ignoreUnknownKeys = true }
    private var cache: MutableList<Visit>? = null

    fun all(context: Context): MutableList<Visit> {
        cache?.let { return it }
        val f = java.io.File(context.filesDir, FILE)
        val list = runCatching {
            if (f.exists()) json.decodeFromString<MutableList<Visit>>(f.readText())
            else mutableListOf()
        }.getOrElse { mutableListOf() }
        cache = list
        return list
    }

    fun add(context: Context, url: String, title: String) {
        if (!url.startsWith("http")) return
        val list = all(context)
        if (list.firstOrNull()?.url == url) return
        list.add(0, Visit(url, title.ifBlank { url }, System.currentTimeMillis()))
        while (list.size > CAP) list.removeAt(list.size - 1)
        flush(context)
    }

    fun search(context: Context, q: String): List<Visit> {
        if (q.isBlank()) return all(context).take(200)
        val s = q.lowercase()
        return all(context)
            .filter { it.url.lowercase().contains(s) || it.title.lowercase().contains(s) }
            .take(200)
    }

    fun clear(context: Context) {
        cache = mutableListOf()
        flush(context)
    }

    private fun flush(context: Context) = runCatching {
        java.io.File(context.filesDir, FILE).writeText(json.encodeToString(all(context)))
    }
}

@Serializable
data class Mark(val url: String, val title: String)

object Bookmarks {
    private const val FILE = "bookmarks.json"
    private val json = Json { ignoreUnknownKeys = true }

    fun all(context: Context): MutableList<Mark> = runCatching {
        val f = java.io.File(context.filesDir, FILE)
        if (f.exists()) json.decodeFromString<MutableList<Mark>>(f.readText()) else mutableListOf()
    }.getOrElse { mutableListOf() }

    fun toggle(context: Context, url: String, title: String): List<Mark> {
        val list = all(context)
        val i = list.indexOfFirst { it.url == url }
        if (i >= 0) list.removeAt(i) else list.add(0, Mark(url, title.ifBlank { url }))
        runCatching {
            java.io.File(context.filesDir, FILE).writeText(json.encodeToString(list))
        }
        return list
    }

    fun has(context: Context, url: String) = all(context).any { it.url == url }
}
