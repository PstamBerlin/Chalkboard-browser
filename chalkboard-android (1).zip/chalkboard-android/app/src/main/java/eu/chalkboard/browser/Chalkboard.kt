package eu.chalkboard.browser

import android.app.Application

/**
 * The engine is started once, here, before any window exists. GeckoRuntime
 * is a singleton by design and starting it twice will crash the app.
 */
class Chalkboard : Application() {
    override fun onCreate() {
        super.onCreate()
        Engine.start(this, Prefs.load(this))
    }
}
