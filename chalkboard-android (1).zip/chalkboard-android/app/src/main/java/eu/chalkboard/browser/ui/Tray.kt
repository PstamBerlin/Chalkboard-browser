package eu.chalkboard.browser.ui

import eu.chalkboard.browser.BuildConfig
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import eu.chalkboard.browser.*

@Composable
fun ChalkTray(browser: Browser, onClose: () -> Unit) {
    val board = browser.board
    val context = LocalContext.current
    val clip = LocalClipboardManager.current

    Column(
        Modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(board.cBg)
            .border(board.dStroke, board.cStroke)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Chalk Tray", color = board.cInk, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f))
            Text("\u00d7", color = board.cInkDim, fontSize = 18.sp,
                modifier = Modifier.clickable { onClose() })
        }

        /* ---------------- gestures ---------------- */
        Section("Gestures", board) {
            Text(
                "Every one of these is yours to change. Gestures call exactly the " +
                    "same code the buttons do.",
                color = board.cInkDim, fontSize = 11.sp, lineHeight = 15.sp,
                modifier = Modifier.padding(bottom = 10.dp),
            )
            Gesture.entries.forEach { g ->
                GestureRow(board, g, browser.gestures[g]) { action ->
                    browser.setGestures(browser.gestures.with(g, action))
                }
            }
            PillButton("Back to the default gestures", board) {
                browser.setGestures(GestureMap())
            }
        }

        /* ---------------- boards ---------------- */
        Section("Boards", board) {
            Board.PRESETS.keys.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(bottom = 6.dp)) {
                    pair.forEach { name ->
                        Box(Modifier.weight(1f)) {
                            PillButton(name, board) {
                                browser.setBoard(Board.PRESETS[name]!!)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            PillButton("Copy this Board", board) {
                clip.setText(AnnotatedString(Board.export(board)))
            }
            PillButton("Paste a Board", board) {
                clip.getText()?.text?.let { Board.import(it)?.let(browser::setBoard) }
            }
        }

        /* ---------------- colours ---------------- */
        Section("Colours", board) {
            ColourRow("Outline", board, board.stroke) { browser.setBoard(board.copy(stroke = it)) }
            ColourRow("Window", board, board.bg) { browser.setBoard(board.copy(bg = it)) }
            ColourRow("Capsules", board, board.fill) { browser.setBoard(board.copy(fill = it)) }
            ColourRow("Page", board, board.page) { browser.setBoard(board.copy(page = it)) }
            ColourRow("Text", board, board.ink) { browser.setBoard(board.copy(ink = it)) }
            ColourRow("Faint text", board, board.inkDim) { browser.setBoard(board.copy(inkDim = it)) }
        }

        /* ---------------- shape ---------------- */
        Section("Outline and shape", board) {
            TokenSlider("Thickness", board, board.strokeWidth, 0f..6f, suffix = "") {
                browser.setBoard(board.copy(strokeWidth = it))
            }
            TokenSlider("Glow", board, board.glow, 0f..30f) {
                browser.setBoard(board.copy(glow = it))
            }
            TokenSlider("Corners", board, board.radius, 0f..30f) {
                browser.setBoard(board.copy(radius = it))
            }
            TokenSlider("Capsules", board, board.capsule, 0f..999f) {
                browser.setBoard(board.copy(capsule = it))
            }
            TokenSlider("Toolbar", board, board.toolbarHeight, 40f..80f) {
                browser.setBoard(board.copy(toolbarHeight = it))
            }
            TokenSlider("Tabs", board, board.tabHeight, 34f..64f) {
                browser.setBoard(board.copy(tabHeight = it))
            }
            TokenSlider("Spacing", board, board.gap, 2f..18f) {
                browser.setBoard(board.copy(gap = it))
            }
            TokenSlider("Text size", board, board.fontSize, 11f..19f) {
                browser.setBoard(board.copy(fontSize = it))
            }
            TokenSlider("Motion", board, board.speedMs.toFloat(), 0f..400f, suffix = "ms") {
                browser.setBoard(board.copy(speedMs = it.toInt()))
            }
        }

        /* ---------------- layout ---------------- */
        Section("Layout", board) {
            Toggle("Toolbar at the bottom", board, browser.prefs.toolbarAtBottom) {
                browser.setPrefs(browser.prefs.copy(toolbarAtBottom = it))
            }
            Toggle("Show the tab strip", board, browser.prefs.showTabStrip) {
                browser.setPrefs(browser.prefs.copy(showTabStrip = it))
            }
            Toggle("Show favicons", board, browser.prefs.showFavicons) {
                browser.setPrefs(browser.prefs.copy(showFavicons = it))
            }
            Toggle("Hide bars when scrolling", board, browser.prefs.hideBarsOnScroll) {
                browser.setPrefs(browser.prefs.copy(hideBarsOnScroll = it))
            }
            Toggle("Pull down to reload", board, browser.prefs.pullToRefresh) {
                browser.setPrefs(browser.prefs.copy(pullToRefresh = it))
            }
            Toggle("Buzz on gestures", board, browser.prefs.haptics) {
                browser.setPrefs(browser.prefs.copy(haptics = it))
            }
        }

        /* ---------------- privacy ---------------- */
        Section("Privacy", board) {
            Toggle("Block ads and trackers", board, browser.prefs.blockAds) {
                browser.setPrefs(browser.prefs.copy(blockAds = it))
            }
            Toggle("Block popups", board, browser.prefs.blockPopups) {
                browser.setPrefs(browser.prefs.copy(blockPopups = it))
            }
            Toggle("Ask before camera and mic", board, browser.prefs.askPermissions) {
                browser.setPrefs(browser.prefs.copy(askPermissions = it))
            }
            Toggle("Keep history", board, browser.prefs.keepHistory) {
                browser.setPrefs(browser.prefs.copy(keepHistory = it))
            }
            Toggle("Clear everything on exit", board, browser.prefs.clearOnExit) {
                browser.setPrefs(browser.prefs.copy(clearOnExit = it))
            }

            Text(
                "Chalkboard tells websites it is an ordinary Firefox, not Chalkboard. " +
                    "A browser nobody else uses is a perfect fingerprint.",
                color = board.cInkDim, fontSize = 11.sp, lineHeight = 15.sp,
                modifier = Modifier.padding(vertical = 10.dp),
            )

            // Encrypted DNS, referrer trimming and fingerprint resistance are
            // not switches here yet, because GeckoView gives no public way to
            // set those preferences from code. They are real settings though,
            // and about:config reaches all of them. Better to say so than to
            // show a switch that quietly does nothing.
            Text(
                "Encrypted DNS, referrer hiding and fingerprint resistance are not " +
                    "switches yet. Open about:config in a tab and search for " +
                    "network.trr.mode, network.http.referer.XOriginPolicy or " +
                    "privacy.resistFingerprinting to set them by hand.",
                color = board.cInkDim, fontSize = 11.sp, lineHeight = 15.sp,
                modifier = Modifier.padding(bottom = 10.dp),
            )

            PillButton("Clear browsing data now", board) { Engine.clearBrowsingData() }
            PillButton("Forget everything", board, strong = true) {
                Engine.clearBrowsingData()
                Prefs.forget(context)
                History.clear(context)
            }
        }

        /* ---------------- extensions ---------------- */
        Section("Extensions", board) {
            Text(
                "Firefox add-ons work here. That is the whole reason Chalkboard " +
                    "runs on Gecko, since Chrome on Android has never allowed them.",
                color = board.cInkDim, fontSize = 11.sp, lineHeight = 15.sp,
                modifier = Modifier.padding(bottom = 10.dp),
            )
            var busy by remember { mutableStateOf<String?>(null) }
            var note by remember { mutableStateOf<String?>(null) }

            Engine.SUGGESTED.forEach { addon ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = busy == null) {
                            busy = addon.id
                            Engine.installExtension(addon.id, addon.url) { ext, err ->
                                busy = null
                                note = if (ext != null) "${addon.name} is on the board"
                                       else "Could not install ${addon.name}"
                            }
                        }
                        .padding(vertical = 8.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(addon.name, color = board.cInk, fontSize = 12.5.sp)
                        Text(addon.what, color = board.cInkDim, fontSize = 11.sp)
                    }
                    Text(
                        if (busy == addon.id) "..." else "Add",
                        color = board.cStroke, fontSize = 12.sp,
                    )
                }
            }
            note?.let {
                Text(it, color = board.cInkDim, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp))
            }
        }

        /* ---------------- search ---------------- */
        Section("Search", board) {
            listOf(
                "DuckDuckGo" to "https://duckduckgo.com/?q=%s",
                "Brave" to "https://search.brave.com/search?q=%s",
                "Mojeek" to "https://www.mojeek.com/search?q=%s",
                "Startpage" to "https://www.startpage.com/sp/search?query=%s",
            ).forEach { (name, url) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { browser.setPrefs(browser.prefs.copy(search = url)) }
                        .padding(vertical = 9.dp),
                ) {
                    Text(name, color = board.cInk, fontSize = 12.5.sp, modifier = Modifier.weight(1f))
                    if (browser.prefs.search == url) {
                        Text("\u2713", color = board.cStroke, fontSize = 13.sp)
                    }
                }
            }
        }

        // Which build is this. Worth having in plain sight during a beta,
        // because the first thing to ask about any bug report is which
        // version it happened on.
        Spacer(Modifier.height(28.dp))
        Text(
            "Chalkboard beta " + BuildConfig.VERSION_NAME.removeSuffix("-beta"),
            color = board.cInkDim,
            fontSize = 11.sp,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun Section(title: String, board: Board, content: @Composable ColumnScope.() -> Unit) {
    var open by remember { mutableStateOf(title == "Gestures") }
    Column(Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { open = !open }
                .padding(top = 16.dp, bottom = 8.dp),
        ) {
            Text(
                title.uppercase(),
                color = board.cStroke, fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold, letterSpacing = 1.6.sp,
                modifier = Modifier.weight(1f),
            )
            Text(if (open) "\u2013" else "+", color = board.cStroke, fontSize = 14.sp)
        }
        AnimatedVisibility(open) { Column(content = content) }
    }
}

/** One gesture, and the list of things it can be made to do. */
@Composable
private fun GestureRow(board: Board, gesture: Gesture, current: Action, onPick: (Action) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { open = !open }
                .padding(vertical = 9.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text(gesture.label, color = board.cInk, fontSize = 12.5.sp)
                Text(current.label, color = board.cStroke, fontSize = 11.sp)
            }
            Text(if (open) "\u2013" else "+", color = board.cInkDim, fontSize = 13.sp)
        }
        AnimatedVisibility(open) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(board.dRadius))
                    .border(1.dp, board.faint(.35f), RoundedCornerShape(board.dRadius))
                    .padding(vertical = 4.dp),
            ) {
                Action.entries.forEach { a ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(a); open = false }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    ) {
                        Text(
                            a.label,
                            color = if (a == current) board.cStroke else board.cInkDim,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f),
                        )
                        if (a == current) Text("\u2713", color = board.cStroke, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
