package eu.chalkboard.browser

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSession.PermissionDelegate

/** One tab. Its session is the live engine, the rest is what the UI draws. */
class Tab(val session: GeckoSession, val private: Boolean) {
    var url by mutableStateOf("")
    var title by mutableStateOf("New tab")
    var loading by mutableStateOf(false)
    var secure by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)

    val host: String
        get() = runCatching {
            android.net.Uri.parse(url).host?.removePrefix("www.") ?: ""
        }.getOrElse { "" }
}

/**
 * The browser itself: which tabs exist, which one you are looking at, and
 * every action that can be triggered from a button, a shortcut or a gesture.
 * Gestures call exactly the same functions the buttons do, so nothing can
 * drift apart.
 */
class Browser(private val context: Context) {

    val tabs: SnapshotStateList<Tab> = mutableStateListOf()
    var activeIndex by mutableIntStateOf(0)
    private val closed = ArrayDeque<String>()

    var prefs by mutableStateOf(Prefs.load(context))
    var board by mutableStateOf(Board.load(context))
    var gestures by mutableStateOf(GestureMap.load(context))
    var bookmarks by mutableStateOf(Bookmarks.all(context).toList())

    /** Set when a popup is stopped, so the UI can offer to open it anyway. */
    var blockedPopup by mutableStateOf<String?>(null)

    var findOpen by mutableStateOf(false)
    var trayOpen by mutableStateOf(false)
    var tabsOpen by mutableStateOf(false)
    var permissionAsk by mutableStateOf<PermissionAsk?>(null)

    val active: Tab? get() = tabs.getOrNull(activeIndex)

    /* ---------------------------------------------------------------- *
     * settings
     * ---------------------------------------------------------------- */

    fun setPrefs(next: Prefs) {
        prefs = next
        Prefs.save(context, next)
        Engine.applyPrefs(next)
    }

    fun setBoard(next: Board) {
        board = next
        Board.save(context, next)
    }

    fun setGestures(next: GestureMap) {
        gestures = next
        GestureMap.save(context, next)
    }

    /* ---------------------------------------------------------------- *
     * tabs
     * ---------------------------------------------------------------- */

    fun newTab(url: String = prefs.homeUrl, private: Boolean = false, background: Boolean = false) {
        val session = Engine.newSession(private)
        val tab = Tab(session, private)
        wire(tab)
        tabs.add(tab)
        if (!background) activeIndex = tabs.lastIndex
        load(tab, url)
    }

    fun closeTab(index: Int = activeIndex) {
        val tab = tabs.getOrNull(index) ?: return
        if (tab.url.startsWith("http")) closed.addLast(tab.url)
        while (closed.size > 20) closed.removeFirst()

        tab.session.close()
        tabs.removeAt(index)

        if (tabs.isEmpty()) newTab()
        else activeIndex = activeIndex.coerceIn(0, tabs.lastIndex)
    }

    fun reopenTab() {
        val url = closed.removeLastOrNull() ?: return
        newTab(url)
    }

    fun nextTab() { if (tabs.isNotEmpty()) activeIndex = (activeIndex + 1) % tabs.size }
    fun prevTab() { if (tabs.isNotEmpty()) activeIndex = (activeIndex - 1 + tabs.size) % tabs.size }

    /* ---------------------------------------------------------------- *
     * navigation
     * ---------------------------------------------------------------- */

    fun load(tab: Tab?, input: String) {
        val t = tab ?: return
        val target = resolve(input)
        if (target == "chalk:new") {
            // Chalk has no website. This page is built into the app, which is
            // why no other browser can open it.
            val page = android.util.Base64.encodeToString(
                ChalkPage.html(board).toByteArray(), android.util.Base64.NO_WRAP
            )
            t.session.loadUri("data:text/html;base64,$page")
            t.url = "chalk:new"
            t.title = "New tab"
        } else {
            t.session.loadUri(target)
        }
    }

    fun go(input: String) = load(active, input)

    fun resolve(input: String): String {
        val s = input.trim()
        if (s.isEmpty()) return prefs.homeUrl
        if (s == "chalk:new") return s
        if (Regex("^[a-z][a-z0-9+.-]*:").containsMatchIn(s)) return s
        if (Regex("^localhost(:\\d+)?([/?#]|$)").containsMatchIn(s)) return "http://$s"
        if (Regex("^[^\\s/?#]+\\.[^\\s/?#]{2,}([/?#].*)?$").matches(s)) return "https://$s"
        return prefs.search.replace("%s", android.net.Uri.encode(s))
    }

    /* ---------------------------------------------------------------- *
     * one place where every action lives
     * ---------------------------------------------------------------- */

    fun run(action: Action) {
        val t = active
        when (action) {
            Action.NOTHING -> {}
            Action.BACK -> t?.session?.goBack()
            Action.FORWARD -> t?.session?.goForward()
            Action.RELOAD -> t?.session?.reload()
            Action.HOME -> go("chalk:new")
            Action.NEW_TAB -> newTab()
            Action.NEW_PRIVATE_TAB -> newTab(private = true)
            Action.CLOSE_TAB -> closeTab()
            Action.REOPEN_TAB -> reopenTab()
            Action.NEXT_TAB -> nextTab()
            Action.PREV_TAB -> prevTab()
            Action.SHOW_TABS -> tabsOpen = !tabsOpen
            Action.OPEN_TRAY -> trayOpen = !trayOpen
            Action.FIND -> findOpen = true
            Action.BOOKMARK -> toggleBookmark()
            Action.TOP_OF_PAGE -> t?.session?.panZoomController?.scrollToTop()
            Action.BOTTOM_OF_PAGE -> t?.session?.panZoomController?.scrollToBottom()
            Action.DESKTOP_SITE -> toggleDesktop()
            Action.SHARE -> share()
            Action.READER -> t?.session?.settings?.let { /* reader mode is a Gecko extension */ }
            Action.ZOOM_IN -> setPrefs(prefs.copy(textScale = (prefs.textScale + 0.1f).coerceAtMost(3f)))
            Action.ZOOM_OUT -> setPrefs(prefs.copy(textScale = (prefs.textScale - 0.1f).coerceAtLeast(0.5f)))
            Action.FORGET -> Engine.clearBrowsingData()
        }
    }

    fun toggleBookmark() {
        val t = active ?: return
        if (!t.url.startsWith("http")) return
        bookmarks = Bookmarks.toggle(context, t.url, t.title)
    }

    private fun toggleDesktop() {
        val t = active ?: return
        val s = t.session.settings
        val mobile = org.mozilla.geckoview.GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        val desktop = org.mozilla.geckoview.GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        s.userAgentMode = if (s.userAgentMode == mobile) desktop else mobile
        t.session.reload()
    }

    private fun share() {
        val t = active ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, t.url)
            putExtra(Intent.EXTRA_SUBJECT, t.title)
        }
        context.startActivity(Intent.createChooser(send, null).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    fun handleGesture(g: Gesture) {
        val action = gestures[g]
        if (action == Action.NOTHING) return
        run(action)
    }

    /* ---------------------------------------------------------------- *
     * engine delegates
     * ---------------------------------------------------------------- */

    private fun wire(tab: Tab) {
        val session = tab.session

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(s: GeckoSession, canGoBack: Boolean) { tab.canBack = canGoBack }
            override fun onCanGoForward(s: GeckoSession, canGoForward: Boolean) { tab.canForward = canGoForward }

            /**
             * A page asking to open a new window. This is where popups are
             * stopped. Returning null refuses it outright, and the UI shows a
             * small bar so a popup you actually wanted is one tap away.
             */
            override fun onNewSession(s: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                if (prefs.blockPopups) {
                    blockedPopup = uri
                    return null
                }
                val child = Engine.newSession(tab.private)
                val newTab = Tab(child, tab.private)
                wire(newTab)
                tabs.add(newTab)
                return GeckoResult.fromValue(child)
            }

            override fun onLoadRequest(
                s: GeckoSession, request: GeckoSession.NavigationDelegate.LoadRequest,
            ): GeckoResult<AllowOrDeny> {
                val u = request.uri

                // Chalk's search box hands the words back to the app rather
                // than picking an engine itself, so changing your search
                // engine in the tray changes it everywhere at once.
                if (u.startsWith("chalk:search")) {
                    val q = android.net.Uri.parse(u).getQueryParameter("q").orEmpty()
                    if (q.isNotBlank()) load(tab, q)
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                if (u == "chalk:new") {
                    load(tab, "chalk:new")
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }

                // Anything that is not web traffic belongs to another app.
                if (!u.startsWith("http")) {
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }
                return GeckoResult.fromValue(AllowOrDeny.ALLOW)
            }
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(s: GeckoSession, url: String) {
                tab.loading = true
                // Where the url gets recorded. onLocationChange would be the
                // usual place, but its shape moves between GeckoView
                // versions and this one does not.
                tab.url = url
                if (prefs.keepHistory && !tab.private) History.add(context, tab.url, tab.title)
            }
            override fun onPageStop(s: GeckoSession, success: Boolean) { tab.loading = false }
            override fun onSecurityChange(
                s: GeckoSession, info: GeckoSession.ProgressDelegate.SecurityInformation,
            ) { tab.secure = info.isSecure }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(s: GeckoSession, title: String?) {
                tab.title = title?.ifBlank { null } ?: tab.host.ifBlank { "New tab" }
            }
            override fun onCloseRequest(s: GeckoSession) {
                val i = tabs.indexOfFirst { it.session === s }
                if (i >= 0) closeTab(i)
            }
        }

        // Camera, microphone and location are refused unless you say yes.
        session.permissionDelegate = object : PermissionDelegate {
            override fun onContentPermissionRequest(
                s: GeckoSession, perm: PermissionDelegate.ContentPermission,
            ): GeckoResult<Int> {
                if (!prefs.askPermissions) {
                    return GeckoResult.fromValue(PermissionDelegate.ContentPermission.VALUE_DENY)
                }
                val result = GeckoResult<Int>()
                permissionAsk = PermissionAsk(
                    origin = perm.uri,
                    what = describe(perm.permission),
                ) { allow ->
                    permissionAsk = null
                    result.complete(
                        if (allow) PermissionDelegate.ContentPermission.VALUE_ALLOW
                        else PermissionDelegate.ContentPermission.VALUE_DENY
                    )
                }
                return result
            }

            override fun onMediaPermissionRequest(
                s: GeckoSession, uri: String,
                video: Array<out PermissionDelegate.MediaSource>?,
                audio: Array<out PermissionDelegate.MediaSource>?,
                callback: PermissionDelegate.MediaCallback,
            ) {
                if (!prefs.askPermissions) return callback.reject()
                permissionAsk = PermissionAsk(uri, "use your camera or microphone") { allow ->
                    permissionAsk = null
                    if (allow) callback.grant(video?.firstOrNull(), audio?.firstOrNull())
                    else callback.reject()
                }
            }
        }
    }

    private fun describe(permission: Int): String = when (permission) {
        PermissionDelegate.PERMISSION_GEOLOCATION -> "know where you are"
        PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION -> "send you notifications"
        PermissionDelegate.PERMISSION_PERSISTENT_STORAGE -> "store data on your phone"
        PermissionDelegate.PERMISSION_MEDIA_KEY_SYSTEM_ACCESS -> "play protected video"
        else -> "use a device feature"
    }

    data class PermissionAsk(
        val origin: String,
        val what: String,
        val answer: (Boolean) -> Unit,
    )
}
