package eu.chalkboard.browser

import android.content.Context
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebExtension

/**
 * Everything about the web engine lives here, so the privacy story is one
 * file you can read start to finish.
 *
 * Chalkboard runs on Gecko, the engine behind Firefox, rather than Chromium.
 * Two reasons. Chrome on Android has never supported extensions, and Gecko
 * ships a real content blocker built into the engine rather than bolted on.
 */
object Engine {

    lateinit var runtime: GeckoRuntime
        private set

    /** A plain Firefox user agent. See the note in [newSession]. */
    private const val FIREFOX_VERSION = "133.0"

    fun start(context: Context, prefs: Prefs) {
        if (::runtime.isInitialized) return

        val blocking = ContentBlocking.Settings.Builder()
            // The ad and tracker blocker. This is Gecko's own, the same one
            // Firefox uses, running inside the engine rather than as an
            // extension, so it cannot be disabled by a page.
            .antiTracking(
                ContentBlocking.AntiTracking.AD or
                    ContentBlocking.AntiTracking.ANALYTIC or
                    ContentBlocking.AntiTracking.SOCIAL or
                    ContentBlocking.AntiTracking.CRYPTOMINING or
                    ContentBlocking.AntiTracking.FINGERPRINTING or
                    ContentBlocking.AntiTracking.CONTENT
            )
            // Total Cookie Protection. Every site gets its own cookie jar, so
            // a tracker on site A cannot read what it set on site B.
            .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
            .enhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
            // Safe Browsing means asking Google about the pages you visit.
            .safeBrowsing(ContentBlocking.SafeBrowsing.NONE)
            .build()

        val settings = GeckoRuntimeSettings.Builder()
            .contentBlocking(blocking)
            .javaScriptEnabled(true)
            .aboutConfigEnabled(true)
            .consoleOutput(false)
            .crashHandler(null)                 // no crash reports leave the phone
            .preferredColorScheme(GeckoRuntimeSettings.COLOR_SCHEME_DARK)
            .build()

        runtime = GeckoRuntime.create(context.applicationContext, settings)

        applyPrefs(prefs)
    }

    /**
     * GeckoView does not expose a public way to set arbitrary about:config
     * preferences, so the deep privacy tuning that would normally live here
     * cannot be applied from code yet. What is left is the part that is
     * public API, which is still most of the protection: the content blocker
     * above, private sessions, and the user agent below.
     *
     * about:config is switched on in the runtime settings, so anything else
     * can still be set by hand in the browser itself.
     */
    fun applyPrefs(prefs: Prefs) {
        if (!::runtime.isInitialized) return
        runtime.settings.fontSizeFactor = prefs.textScale
        runtime.settings.automaticFontSizeAdjustment = false
    }

    /** Build a session, which is one tab. */
    fun newSession(private: Boolean = false): GeckoSession {
        val s = GeckoSession(
            GeckoSessionSettings.Builder()
                .usePrivateMode(private)
                .useTrackingProtection(true)
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                // A browser nobody else uses is a perfect fingerprint. If
                // Chalkboard announced itself you would be one of a handful
                // of people on earth with that user agent, which makes you
                // easier to follow, not harder. So it says plain Firefox.
                .userAgentOverride(
                    "Mozilla/5.0 (Android 13; Mobile; rv:$FIREFOX_VERSION) " +
                        "Gecko/$FIREFOX_VERSION Firefox/$FIREFOX_VERSION"
                )
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
                .build()
        )
        s.open(runtime)
        return s
    }

    /* ---------------------------------------------------------------- *
     * extensions
     * ---------------------------------------------------------------- */

    private val installed = mutableMapOf<String, WebExtension>()

    fun extensions(): List<WebExtension> = installed.values.toList()

    /**
     * Install an add-on from a URL. Firefox add-ons are .xpi files, and the
     * ones on addons.mozilla.org have a stable "latest" link, so uBlock
     * Origin can be installed with one tap and no store account.
     */
    fun installExtension(id: String, url: String, onDone: (WebExtension?, Throwable?) -> Unit) {
        runtime.webExtensionController
            .install(url)
            .accept({ ext ->
                if (ext != null) installed[id] = ext
                onDone(ext, null)
            }, { error ->
                onDone(null, error)
            })
    }

    fun uninstallExtension(id: String, onDone: () -> Unit) {
        val ext = installed[id] ?: return onDone()
        runtime.webExtensionController.uninstall(ext).accept {
            installed.remove(id)
            onDone()
        }
    }

    /** The add-ons worth offering by name, so you do not have to hunt for URLs. */
    val SUGGESTED = listOf(
        Addon("ublock", "uBlock Origin", "The strong ad and tracker blocker",
            "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi"),
        Addon("darkreader", "Dark Reader", "Makes every site dark",
            "https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi"),
        Addon("clearurls", "ClearURLs", "Strips tracking junk out of links",
            "https://addons.mozilla.org/firefox/downloads/latest/clearurls/latest.xpi"),
        Addon("cookies", "Cookie AutoDelete", "Throws cookies away when you leave",
            "https://addons.mozilla.org/firefox/downloads/latest/cookie-autodelete/latest.xpi"),
    )

    data class Addon(val id: String, val name: String, val what: String, val url: String)

    /* ---------------------------------------------------------------- *
     * forgetting
     * ---------------------------------------------------------------- */

    fun clearBrowsingData(onDone: () -> Unit = {}) {
        runtime.storageController
            .clearData(
                org.mozilla.geckoview.StorageController.ClearFlags.COOKIES or
                    org.mozilla.geckoview.StorageController.ClearFlags.NETWORK_CACHE or
                    org.mozilla.geckoview.StorageController.ClearFlags.IMAGE_CACHE or
                    org.mozilla.geckoview.StorageController.ClearFlags.DOM_STORAGES or
                    org.mozilla.geckoview.StorageController.ClearFlags.AUTH_SESSIONS or
                    org.mozilla.geckoview.StorageController.ClearFlags.SITE_SETTINGS
            )
            .accept { onDone() }
    }
}
