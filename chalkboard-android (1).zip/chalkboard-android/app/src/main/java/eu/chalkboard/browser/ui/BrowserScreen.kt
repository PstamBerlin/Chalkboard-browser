package eu.chalkboard.browser.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.viewinterop.AndroidView
import eu.chalkboard.browser.*
import org.mozilla.geckoview.GeckoView

@Composable
fun BrowserScreen(browser: Browser) {
    val board = browser.board
    val prefs = browser.prefs
    val haptic = LocalHapticFeedback.current

    fun fire(g: Gesture) {
        if (browser.gestures[g] == Action.NOTHING) return
        if (prefs.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        browser.handleGesture(g)
    }

    Box(Modifier.fillMaxSize().background(board.cBg)) {

        Column(Modifier.fillMaxSize()) {

            /* ---- chrome at the top, unless you moved it ---- */
            if (!prefs.toolbarAtBottom) Chrome(browser, ::fire)

            /* ---- the web page ---- */
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(board.cPage)
                    // Edge swipes and two finger swipes belong to the page area.
                    .swipes(edgeMode = true) { dir, fingers, edge ->
                        when {
                            fingers >= 2 && dir == Dir2.UP -> fire(Gesture.PAGE_TWO_UP)
                            fingers >= 2 && dir == Dir2.DOWN -> fire(Gesture.PAGE_TWO_DOWN)
                            edge == Edge.LEFT && dir == Dir2.RIGHT -> fire(Gesture.EDGE_SWIPE_LEFT)
                            edge == Edge.RIGHT && dir == Dir2.LEFT -> fire(Gesture.EDGE_SWIPE_RIGHT)
                        }
                    },
            ) {
                val tab = browser.active
                if (tab != null) {
                    AndroidView(
                        factory = { ctx -> GeckoView(ctx) },
                        update = { view ->
                            if (view.session !== tab.session) {
                                view.releaseSession()
                                view.setSession(tab.session)
                            }
                        },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }

            /* ---- chrome at the bottom, which is where a phone wants it ---- */
            if (prefs.toolbarAtBottom) Chrome(browser, ::fire)
        }

        /* ---- the tray slides over from the right ---- */
        AnimatedVisibility(
            visible = browser.trayOpen,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
            modifier = Modifier.align(Alignment.CenterEnd),
        ) {
            ChalkTray(browser) { browser.trayOpen = false }
        }
    }
}

/**
 * The bars. Kept as one composable so it can be dropped above or below the
 * page without duplicating anything.
 */
@Composable
private fun Chrome(browser: Browser, fire: (Gesture) -> Unit) {
    val board = browser.board
    Column(
        Modifier
            .fillMaxWidth()
            .background(board.cBg)
            .swipes { dir, fingers, _ ->
                when {
                    fingers >= 2 -> fire(Gesture.BAR_TWO_FINGER)
                    dir == Dir2.LEFT -> fire(Gesture.BAR_SWIPE_LEFT)
                    dir == Dir2.RIGHT -> fire(Gesture.BAR_SWIPE_RIGHT)
                    dir == Dir2.UP -> fire(Gesture.BAR_SWIPE_UP)
                    dir == Dir2.DOWN -> fire(Gesture.BAR_SWIPE_DOWN)
                }
            }
            .taps(
                onLongPress = { fire(Gesture.BAR_LONG_PRESS) },
                onDoubleTap = { fire(Gesture.BAR_DOUBLE_TAP) },
            ),
    ) {
        PermissionBar(browser)
        PopupBar(browser)
        FindBar(browser)
        if (browser.prefs.showTabStrip) TabStrip(browser)
        Toolbar(browser)
    }
}
