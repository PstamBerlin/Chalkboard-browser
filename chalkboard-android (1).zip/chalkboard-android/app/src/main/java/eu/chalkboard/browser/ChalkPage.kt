package eu.chalkboard.browser

/**
 * Chalk is built into the app. There is no chalk.com and there never needs
 * to be one, which is the point: no domain to buy, no server to run, no
 * hosting bill, and nothing anyone can visit without Chalkboard.
 *
 * It is generated from the current Board so the new tab page always matches
 * whatever the rest of the browser looks like.
 */
object ChalkPage {

    fun html(board: Board): String = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Chalk</title>
<style>
  :root{
    --bg:${board.bg};
    --fill:${board.fill};
    --stroke:${board.stroke};
    --ink:${board.ink};
    --dim:${board.inkDim};
    --radius:${board.capsule}px;
    --glow:${board.glow}px;
    --sw:${board.strokeWidth}px;
  }
  *{box-sizing:border-box}
  html,body{height:100%;margin:0}
  body{
    background:var(--bg);color:var(--ink);
    font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
    -webkit-font-smoothing:antialiased;
    display:grid;place-items:center;padding:24px;
  }
  main{width:100%;max-width:460px;margin-bottom:14vh}
  .ln{
    display:flex;align-items:center;height:52px;padding:0 20px;
    border:var(--sw) solid var(--stroke);border-radius:var(--radius);
    background:var(--fill);
    box-shadow:0 0 var(--glow) color-mix(in srgb, var(--stroke) 45%, transparent);
  }
  input{flex:1;min-width:0;border:0;background:none;color:var(--ink);
    font:inherit;font-size:17px}
  input:focus{outline:none}
  input::placeholder{color:var(--dim)}
  .tag{margin:16px 0 0;text-align:center;font-size:10px;
    letter-spacing:.22em;text-transform:uppercase;color:var(--dim)}
</style>
</head>
<body>
<main>
  <div class="ln">
    <input id="q" type="text" spellcheck="false" autocomplete="off"
           aria-label="Search on Chalk" placeholder="Write something">
  </div>
  <p class="tag">Chalk</p>
</main>
<script>
  document.getElementById('q').addEventListener('keydown', function(e){
    if (e.key !== 'Enter') return;
    var raw = e.currentTarget.value.trim();
    if (!raw) return;
    // The app owns the search engine choice, so hand the words back to it.
    location.href = 'chalk:search?q=' + encodeURIComponent(raw);
  });
</script>
</body>
</html>
""".trimIndent()
}
