# Chalkboard for Android, beta 0.5

A browser that is empty by default, blocks ads and popups, keeps nothing,
and lets you remap every gesture.

Built on **GeckoView**, the engine behind Firefox, not Chromium. Two
reasons for that choice, and they are the whole design:

1. **Chrome on Android has never supported extensions.** Gecko does. If
   add-ons matter, Chromium is the wrong engine on phones.
2. Gecko ships a real content blocker *inside the engine*, so ads and
   trackers are stopped before a page can even ask for them, and no site
   can switch it off.

## Build it

You need **Android Studio** and a **JDK 17**.

Open the `chalkboard-android` folder in Android Studio. The first thing
it will do is finish setting up Gradle, because the wrapper needs a small
binary file that cannot travel in a source zip. Let it. Then either press
Run, or from a terminal:

```
./gradlew assembleDebug
```

The APK lands in `app/build/outputs/apk/debug/`. Copy it to your phone
and install it. No Play Store account, no signing key, no review.

To put it straight onto a plugged in phone:

```
./gradlew installDebug
```

If you would rather not open Android Studio first and you already have
Gradle installed, `gradle wrapper` in the project folder does the same
setup job.

**Versions.** The GeckoView, Compose and Gradle versions in
`app/build.gradle.kts` are the ones that were current when this was
written. If Android Studio complains, let it bump them. GeckoView
follows the Firefox release calendar and gets a new version roughly
every four weeks, and bumping it is how you stay on current security
fixes.

## Gestures

The part that makes a phone browser feel good instead of feeling like a
website in a box. Twelve gestures, each remappable to any of twenty
three actions, all in the tray.

Defaults:

| Gesture | Does |
| --- | --- |
| Swipe left on the bar | Next tab |
| Swipe right on the bar | Previous tab |
| Swipe up on the bar | Show all tabs |
| Swipe down on the bar | Reload |
| Hold the bar | Open the Chalk Tray |
| Double tap the bar | Jump to the top |
| Two fingers on the bar | Close tab |
| Swipe in from the left edge | Back |
| Swipe in from the right edge | Forward |
| Two fingers up on the page | New tab |
| Two fingers down on the page | Find in page |

Gestures call exactly the same functions the buttons call. There is one
`run(action)` in `Browser.kt` and everything goes through it, so a
gesture and a button can never drift apart.

## Blocking

**Ads and trackers.** Gecko's own Enhanced Tracking Protection at strict
level, covering ads, analytics, social trackers, cryptominers,
fingerprinters and tracking content. Plus Total Cookie Protection, which
gives every site its own cookie jar so a tracker on one site cannot read
what it stored on another.

**Popups.** Refused at the point the page asks for a new window, with a
small bar offering to open it anyway for the one time you actually
wanted it. Sites also cannot open windows with no toolbar, or move and
resize windows.

**Cookie banners** are auto rejected where Gecko knows how.

For the heavy artillery, the tray installs **uBlock Origin** with one
tap, straight from addons.mozilla.org. Also offered: Dark Reader,
ClearURLs and Cookie AutoDelete.

## Privacy

All in `Engine.kt`, one file, readable in one sitting.

- No telemetry to anyone, Mozilla included
- Safe Browsing off, so Google is never asked about the pages you visit
- DNS over HTTPS, mode 3, so it never quietly falls back to plain DNS
- Cross origin referrers trimmed
- Tracking parameters like `?fbclid=` stripped out of URLs
- Prefetch, DNS prefetch and the network predictor all off
- Global Privacy Control on
- Camera, microphone and location refused unless you say yes
- Optional fingerprint resistance
- **Reports itself as an ordinary Firefox.** A browser nobody else uses
  is a perfect fingerprint. Same reason Tor makes everyone look
  identical.

Everything it remembers is a JSON file in the app's private folder.
History, bookmarks, your Board, your gestures. Nothing else, nowhere
else.

## Customising

Nothing in the UI hard codes a colour or a size. Every widget reads from
`Board`, which is why the tray can change anything without touching
layout code.

- Six colours, each with a hex field for the exact value, hue,
  saturation and lightness sliders, and a grid of pure colours
- Outline thickness, glow, corners, capsule roundness
- Toolbar height, tab height, spacing, text size, motion speed
- Toolbar top or bottom, tab strip on or off, favicons on or off
- Five Boards to start from, including Paper if you want light
- **Copy this Board** puts the whole look on your clipboard as text, so
  you can send your browser to a friend

## Files

```
Engine.kt        the engine, blocking, popups, extensions, privacy
Browser.kt       tabs, delegates, and every action in one place
Gestures.kt      what gestures exist, what they can do, the detector
Board.kt         design tokens, presets, export and import
Prefs.kt         settings, history, bookmarks, all local JSON
ChalkPage.kt     the built in new tab page
ui/BrowserScreen.kt  the screen, gesture wiring, engine view
ui/Chrome.kt     toolbar, tabs, find, popup bar, permission bar
ui/Tray.kt       every setting
ui/Bits.kt       shared widgets and the colour picker
res/drawable/ic_launcher_foreground.xml   the geometric C
```

The launcher icon is a vector, not a set of PNGs, so it stays sharp at
every size and Android can recolour it to match the wallpaper on phones
that do themed icons.

## Honest limits

- **This has not been compiled.** It was written without an Android SDK
  to hand. Expect Android Studio to flag a few import and API details on
  the first build, especially around GeckoView method names, which move
  between versions. The structure is sound, the details may need a nudge.
- The APK is large. GeckoView bundles the entire engine, roughly 30 to
  40 MB per architecture. The build splits by architecture to keep each
  one down.
- No Widevine, so Netflix and Spotify will not play.
- Tab state is not saved across an app restart yet.
- Downloads use Gecko's default handling, there is no manager screen.

## Next

- A tab grid instead of the strip, since strips are cramped on phones
- Save and restore tabs across restarts
- Per site permission memory
- Reader view
- Chalk as a real results page so search never leaves the app
